using System.Collections.Generic;

public class Morse {
    Dictionary<char, string> cod = new Dictionary<char, string>();

    public Morse()
    {
       
        {
            cod.Add('A' , ".-");
            cod.Add('B' , "-...");
            cod.Add('C' , "-.-.");
            cod.Add('D' , "-..");
             cod.Add('E' , ".");
            cod.Add ('F' , "..-.");
             cod.Add('G' , "--.");
             cod.Add('H' , "....");
             cod.Add('I' , "..");
             cod.Add('J' , ".---");
             cod.Add('K' , "-.-");
             cod.Add('L' , ".-..");
             cod.Add('M' , "--");
             cod.Add('N' , "-.");
             cod.Add('O' , "---");
             cod.Add('P' , ".--.");
             cod.Add('Q' , "--.-");
             cod.Add('R' , ".-.");
             cod.Add('S' , "...");
            cod.Add ('T' , "-");
            cod.Add ('U' , "..-");
             cod.Add('V' , "...-");
            cod.Add ('W' , ".--");
             cod.Add('X' , "-..-");
            cod.Add ('Y' , "-.--");
             cod.Add('Z' , "--..");
    
        };

        Dictionary<string, string> dec = new Dictionary<string, string>()
        {
            {".-" , "A"},
            {"-...","B"},
            {"-.-.","C"},
            {"-..", "D" },
            {"." ,"E" },
            {"..-." ,"F" },
            {"--." ,"G" },
            {"...." ,"H" },
            {".." , "I" },
            {".---","J" },
            {"-.-","K" },
            {".-..","L" },
            {"--","M"},
            {"-.","N" },
            {"---","O" },
            {".--.","P" },
            { "--.-","Q"},
            {".-.","R"},
            {"...","S"},
            {"-","T"  },
            { "..-","U"},
            { "...-","V"},
            { ".--","W" },
            {"-..-","X" },
            { "-.--","Y"},
            {"--..","Z"},
        };
    }
    public Morse(string Alfabeto)
    {
    }

    public string Codifica( string s )
    {
        string cr ="";
        int i=0;
        foreach(char c in s.ToUpper())
        {
            if(i==0){
                cr = cr + cod[c];    
            }
            else{
                cr = cr+" "+ cod[c];
            }
            i++;
        }
        
        return cr ;
    }
    public string Decodifica( string s )
    {
        for(int i=0; i<= s.Length; i++){
            
        }
        return;
    }
}